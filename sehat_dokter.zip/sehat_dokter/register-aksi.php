<?php 
include 'koneksi.php';

// Mendapatkan data dari form
$nama_lengkap = mysqli_real_escape_string($host, $_POST['nama_lengkap']);
$nomor_identitas = mysqli_real_escape_string($host, $_POST['nomor_identitas']);
$tempat_lahir = mysqli_real_escape_string($host, $_POST['tempat_lahir']);
$tanggal_lahir = mysqli_real_escape_string($host, $_POST['tanggal_lahir']);
$nomor_handphone = mysqli_real_escape_string($host, $_POST['nomor_handphone']);
$no_bpjs = mysqli_real_escape_string($host, $_POST['no_bpjs']);
$jenis_kelamin = mysqli_real_escape_string($host, $_POST['jenis_kelamin']);
$agama = mysqli_real_escape_string($host, $_POST['agama']);
$nama_dokter = mysqli_real_escape_string($host, $_POST['nama_dokter']);
$waktu_periksa = mysqli_real_escape_string($host, $_POST['waktu_periksa']);
$pekerjaan = mysqli_real_escape_string($host, $_POST['pekerjaan']);
$tanggal_periksa = mysqli_real_escape_string($host, $_POST['tanggal_periksa']);

// Melakukan query untuk menambahkan data ke database
$query = "INSERT INTO form_pendataran (nama_lengkap, nomor_identitas, tempat_lahir, tanggal_lahir, nomor_handphone, no_bpjs,jenis_kelamin, agama, nama_dokter, waktu_periksa, pekerjaan, tanggal_periksa) VALUES ('$nama_lengkap', '$nomor_identitas', '$tempat_lahir', '$tanggal_lahir', '$nomor_handphone', '$no_bpjs','$jenis_kelamin', '$agama', '$nama_dokter', '$waktu_periksa', '$pekerjaan', '$tanggal_periksa')";

// Memeriksa apakah query berhasil dijalankan
if(mysqli_query($host, $query)) {
    // Jika berhasil, redirect ke halaman index dengan pesan sukses
    header("location:succes.php?pesan=input");
} else {
    // Jika gagal, redirect ke halaman index dengan pesan error
    header("location:tidak_succes.php?pesan=error");
}

// Tutup koneksi ke database
mysqli_close($host);
?>
