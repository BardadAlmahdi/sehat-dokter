<?php
include 'koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

// Membuat koneksi ke database menggunakan MySQLi
$mysqli = new mysqli("localhost", "root", "", "form_pendataran");

// Memeriksa koneksi
if ($mysqli->connect_error) {
    die("Koneksi ke database gagal: " . $mysqli->connect_error);
}

// Melakukan query menggunakan prepared statement untuk mencegah SQL injection
$stmt = $mysqli->prepare("SELECT * FROM admin WHERE username=? AND password=?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();

// Mengambil hasil query
$result = $stmt->get_result();

// Memeriksa jumlah baris yang cocok
$cek = $result->num_rows;

// Menutup statement dan koneksi
$stmt->close();
$mysqli->close();

// Memeriksa apakah login berhasil
if($cek > 0) {
    // Jika berhasil, redirect ke halaman index dengan pesan sukses
    header("location:login_succes.php?pesan=input");
} else {
    // Jika gagal, redirect ke halaman index dengan pesan error
    header("location:login_tidak_succes.php?pesan=error");
}
?>
