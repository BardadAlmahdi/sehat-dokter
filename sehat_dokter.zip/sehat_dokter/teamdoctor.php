<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>sehat_dokter</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Custom Google font-->
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body class="d-flex flex-column h-100 bg-light">
        <main class="flex-shrink-0">
            <!-- Navigation-->
            <nav class="navbar navbar-expand-lg navbar-light bg-white py-3">
                <div class="container px-5">
                    <a class="navbar-brand" href="index.php"><span class="fw-bolder text-primary">Sehat Dokter</span></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 small fw-bolder">
                            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="patient registration.php">Patient Registration</a></li>
                            <li class="nav-item"><a class="nav-link" href="teamdoctor.php">Team of Doctor</a></li>
                            <li class="nav-item"><a class="nav-link" href="login.php">Login Admin</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- Projects Section-->
            <section class="py-5">
    <div class="container px-5 mb-5">
        <div class="text-center mb-5">
            <h1 class="display-5 fw-bolder mb-0"><span class="text-gradient d-inline">Team of Doctor</span></h1>
        </div>
        <div class="row gx-5 justify-content-center">
            <div class="col-lg-11 col-xl-9 col-xxl-8">
                <!-- Project Card 1-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Dr. John Smith, Spesialis Bedah Jantung.</h2>
                                <p>Dr. John Smith adalah seorang spesialis bedah jantung dengan pengalaman lebih dari 20 tahun dalam bidangnya. Beliau telah sukses melakukan ribuan operasi jantung dengan tingkat keberhasilan yang sangat tinggi. Keahlian dan dedikasinya dalam memberikan perawatan kardiovaskular membuatnya diakui sebagai salah satu ahli terkemuka di bidang bedah jantung. Dr. Smith selalu berkomitmen untuk memberikan pelayanan terbaik kepada setiap pasien, dengan pendekatan yang ramah dan perhatian kepada kebutuhan individu setiap pasien.
                                </p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st4.depositphotos.com/20363444/41421/i/450/depositphotos_414214512-stock-photo-doctor-crossed-arms-looking-camera.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 2-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Dr. Denny Ivan RIfai, Spesialis Penyakit Kulit.</h2>
                                <p>Dr. Denny Ivan RIfai adalah seorang ahli dermatologi dengan pengalaman luas dalam diagnosis dan pengobatan berbagai penyakit kulit. Ia berkomitmen untuk memberikan perawatan terbaik kepada pasiennya dan memiliki reputasi yang baik dalam menangani berbagai kondisi kulit.</p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st3.depositphotos.com/1177973/13224/i/450/depositphotos_132246354-stock-photo-young-male-doctor-with-tablet.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 3-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Dr. Sarah Johnson, Dokter Umum.</h2>
                                <p>Dr. Sarah Johnson adalah seorang dokter umum yang berdedikasi tinggi dalam memberikan perawatan kesehatan kepada pasien-pasiennya. Dengan pengalaman yang luas dan pengetahuan mendalam tentang berbagai penyakit dan kondisi medis, Dr. Johnson memberikan pelayanan medis yang berkualitas dan komprehensif kepada setiap pasien. Beliau selalu berusaha untuk memahami kebutuhan kesehatan individu setiap pasien dan memberikan perawatan yang terbaik sesuai dengan kondisi dan kebutuhan masing-masing.</p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st3.depositphotos.com/3889193/35772/i/450/depositphotos_357721126-stock-photo-confident-female-doctor-posing-her.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 4-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Prof. Dr. Michael Brown, Ahli Gastroenterologi.</h2>
                                <p>Prof. Dr. Michael Brown adalah seorang ahli gastroenterologi terkemuka yang memiliki pengalaman bertahun-tahun dalam diagnosis, pengobatan, dan penelitian penyakit saluran pencernaan. Dengan keahlian dan dedikasinya dalam bidang gastroenterologi, Prof. Dr. Brown telah membantu ribuan pasien dalam mengatasi berbagai masalah pencernaan, termasuk gangguan lambung, penyakit hati, dan gangguan usus. Beliau juga aktif dalam penelitian ilmiah untuk mengembangkan metode diagnosis dan pengobatan yang inovatif. Prof. Dr. Brown selalu berkomitmen untuk memberikan pelayanan terbaik kepada setiap pasien dan mendukung mereka dalam perjalanan menuju kesehatan pencernaan yang optimal.
                                </p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st3.depositphotos.com/1743476/32257/i/450/depositphotos_322579018-stock-photo-smiling-doctor-standing-on-grey.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 5-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Dr. Linda Williams, Spesialis Mata</h2>
                                <p>Dr. Linda Williams adalah seorang spesialis mata berpengalaman yang peduli terhadap kesehatan mata pasien-pasiennya. Dengan keahlian dan pengetahuannya yang mendalam dalam bidang oftalmologi, Dr. Williams telah berhasil mengatasi berbagai masalah mata, mulai dari gangguan penglihatan hingga penyakit mata kronis. Beliau sangat memahami pentingnya penglihatan bagi kualitas hidup seseorang, sehingga selalu berusaha memberikan perawatan terbaik dan solusi yang tepat untuk setiap pasien. Dr. Williams juga aktif dalam memberikan edukasi kepada masyarakat tentang pentingnya merawat mata dan menjaga kesehatan visual secara umum.</p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st3.depositphotos.com/10654668/13512/i/450/depositphotos_135128174-stock-photo-female-doctor-with-stethoscope.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 6-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Dr. David Lee, Ahli THT (Telinga, Hidung, Tenggorokan).</h2>
                                <p>Dr. David Lee adalah seorang ahli THT (Telinga, Hidung, Tenggorokan) dengan pengalaman bertahun-tahun dalam diagnosis dan pengobatan berbagai kondisi medis yang berkaitan dengan telinga, hidung, dan tenggorokan. Dengan pengetahuannya yang mendalam dalam bidang ini, Dr. Lee telah membantu ribuan pasien dalam mengatasi masalah kesehatan THT mereka. Beliau berkomitmen untuk memberikan pelayanan terbaik kepada pasien-pasiennya dengan pendekatan yang holistik dan perhatian kepada detail. Dr. Lee juga aktif dalam penelitian dan pengembangan teknik terbaru dalam bidang THT untuk meningkatkan kualitas hidup pasien-pasiennya.</p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st4.depositphotos.com/1325771/39154/i/450/depositphotos_391545206-stock-photo-happy-male-medical-doctor-portrait.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 7-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Dr. Jennifer Davis, Spesialis Obstetri dan Ginekologi.</h2>
                                <p>Dr. Jennifer Davis adalah seorang spesialis obstetri dan ginekologi yang berdedikasi tinggi dalam memberikan perawatan kesehatan kepada wanita. Dengan pengalaman luas dan pengetahuan mendalam tentang kehamilan, persalinan, serta masalah kesehatan reproduksi wanita, Dr. Davis memberikan pelayanan medis yang komprehensif dan peduli terhadap setiap pasiennya. Beliau memahami pentingnya perawatan prenatal yang baik dan memberikan dukungan kepada wanita selama masa kehamilan mereka. Selain itu, Dr. Davis juga ahli dalam menangani berbagai kondisi ginekologi, seperti gangguan menstruasi, kista ovarium, dan masalah kesehatan reproduksi lainnya. Dengan pendekatan yang empatik dan profesional, Dr. Davis berusaha memberikan solusi terbaik dan perawatan yang nyaman bagi setiap pasien wanita yang datang kepadanya.</p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st.depositphotos.com/1771835/1477/i/450/depositphotos_14779771-stock-photo-portrait-of-confident-young-doctor.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 8-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Dr. Karen Garcia, Ahli Psikiatri.</h2>
                                <p>Dr. Karen Garcia adalah seorang ahli psikiatri dengan pengalaman luas dalam diagnosis, pengobatan, dan dukungan untuk gangguan mental dan emosional. Beliau memiliki keahlian dalam menangani berbagai kondisi psikiatri, termasuk depresi, kecemasan, gangguan bipolar, dan skizofrenia. Dr. Garcia sangat memahami pentingnya perawatan kesehatan mental yang holistik dan individu, dan selalu berusaha untuk menciptakan lingkungan yang aman dan mendukung bagi pasien-pasiennya. Dengan pendekatan yang empatik dan pengetahuan yang mendalam tentang terapi dan obat-obatan psikiatri, Dr. Garcia membantu pasien-pasiennya mengatasi tantangan mental dan meningkatkan kualitas hidup mereka. Beliau juga aktif dalam meningkatkan kesadaran masyarakat tentang kesehatan mental dan menghilangkan stigma terkait gangguan mental.</p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st3.depositphotos.com/4678277/18409/i/450/depositphotos_184092796-stock-photo-portrait-of-happy-smiling-confident.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 9-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Dr. Robert Clark, Dokter Anak.</h2>
                                <p>Dr. Robert Clark adalah seorang dokter anak yang peduli dan berdedikasi dalam memberikan perawatan kesehatan kepada anak-anak. Dengan pengalaman dan pengetahuan yang mendalam dalam pediatri, Dr. Clark merawat anak-anak dengan penuh perhatian dan kepedulian. Beliau memiliki keahlian dalam diagnosis dan pengobatan berbagai kondisi medis yang memengaruhi anak-anak, mulai dari penyakit umum hingga kondisi kronis. Dr. Clark juga berfokus pada pencegahan penyakit dan perkembangan sehat anak-anak, serta memberikan dukungan kepada orang tua dalam merawat anak-anak mereka. Dengan pendekatan yang ramah dan perhatian kepada detail, Dr. Clark menciptakan lingkungan yang nyaman dan aman bagi anak-anak, sehingga mereka merasa dihargai dan didengar dalam perawatan kesehatan mereka.</p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st3.depositphotos.com/12982378/17554/i/450/depositphotos_175549982-stock-photo-doctor.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 10-->
                <div class="card overflow-hidden shadow rounded-4 border-0 mb-5">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Dr. James Anderson, Spesialis Bedah Ortopedi..</h2>
                                <p>Dr. James Anderson adalah seorang spesialis bedah ortopedi dengan pengalaman luas dalam diagnosis, pengobatan, dan pembedahan berbagai kondisi muskuloskeletal. Beliau memiliki keahlian khusus dalam mengatasi masalah tulang, sendi, otot, dan cedera pada sistem muskuloskeletal. Dengan dedikasi tinggi terhadap perawatan pasien, Dr. Anderson memastikan bahwa setiap pasien menerima perawatan yang terbaik sesuai dengan kebutuhan mereka. Selain melakukan prosedur pembedahan ortopedi kompleks, beliau juga berfokus pada terapi konservatif dan rehabilitasi pasien untuk memastikan pemulihan maksimal. Dr. Anderson juga aktif dalam penelitian ilmiah dan pengembangan teknik bedah terkini untuk meningkatkan hasil perawatan pasien. Dengan pendekatan yang holistik dan berbasis bukti, Dr. Anderson membantu pasien mengatasi rasa sakit, memperbaiki fungsi tubuh, dan meningkatkan kualitas hidup mereka.</p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st2.depositphotos.com/3889193/6552/i/450/depositphotos_65526707-stock-photo-confident-doctor-posing.jpg" alt="..." />
                        </div>
                    </div>
                </div>
                <!-- Project Card 11-->
                <div class="card overflow-hidden shadow rounded-4 border-0">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center">
                            <div class="p-5">
                                <h2 class="fw-bolder">Prof. Dr. Susan Turner, Ahli Radiologi.</h2>
                                <p>Prof. Dr. Susan Turner adalah seorang ahli radiologi terkemuka dengan pengalaman bertahun-tahun dalam diagnosis penyakit dan kondisi medis melalui teknologi pencitraan medis. Beliau memiliki pengetahuan mendalam tentang berbagai metode pencitraan seperti sinar-X, CT scan, MRI, dan ultrasonografi. Dengan keahliannya, Prof. Dr. Turner membantu dokter dan spesialis lain dalam membuat diagnosis yang akurat dan merencanakan perawatan yang efektif untuk pasien. Selain menganalisis gambar medis, beliau juga terlibat dalam penelitian untuk meningkatkan teknologi pencitraan dan metode diagnosis. Prof. Dr. Turner berkomitmen untuk memberikan kontribusi positif dalam bidang radiologi, membantu pasien mendapatkan diagnosis yang tepat, dan meningkatkan pengobatan penyakit dan kondisi medis melalui teknologi pencitraan yang canggih.</p>
                            </div>
                            <img class="img-fluid d-block mx-auto" style="object-fit: cover; width: 300px; height: 400px;" src="https://st4.depositphotos.com/2024219/25128/i/450/depositphotos_251282572-stock-photo-young-doctor-woman-arms-crossed.jpg" alt="..." />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

            <!-- Call to action section-->
            <section class="py-5 bg-gradient-primary-to-secondary text-white">
                <div class="container px-5 my-5">
                    <div class="text-center">
                        <h2 class="display-4 fw-bolder mb-4">There's no need to doubt our service</h2>
                        <a class="btn btn-outline-light btn-lg px-5 py-3 fs-6 fw-bolder" href="teamdoctor.php">Team of Doctor</a>
                    </div>
                </div>
            </section>
        </main>
        <!-- Footer-->
        <footer class="bg-white py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0">Healthy &middot; Happy &middot; Professional</div></div>
                    <div class="col-auto">
                        <a class="small" href="#!">Privacy</a>
                        <span class="mx-1">&middot;</span>
                        <a class="small" href="#!">Terms</a>
                        <span class="mx-1">&middot;</span>
                        <a class="small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
