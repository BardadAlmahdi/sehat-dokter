<?php 
include 'koneksi.php';

// Mendapatkan data dari form
$no_rm = mysqli_real_escape_string($host, $_POST['no_rm']);
$nama_lengkap = mysqli_real_escape_string($host, $_POST['nama_lengkap']);
$nomor_identitas = mysqli_real_escape_string($host, $_POST['nomor_identitas']);
$tempat_lahir = mysqli_real_escape_string($host, $_POST['tempat_lahir']);
$tanggal_lahir = mysqli_real_escape_string($host, $_POST['tanggal_lahir']);
$nomor_handphone = mysqli_real_escape_string($host, $_POST['nomor_handphone']);
$no_bpjs = mysqli_real_escape_string($host, $_POST['no_bpjs']);
$jenis_kelamin = mysqli_real_escape_string($host, $_POST['jenis_kelamin']);
$agama = mysqli_real_escape_string($host, $_POST['agama']);
$nama_dokter = mysqli_real_escape_string($host, $_POST['nama_dokter']);
$waktu_periksa = mysqli_real_escape_string($host, $_POST['waktu_periksa']);
$pekerjaan = mysqli_real_escape_string($host, $_POST['pekerjaan']);
$tanggal_periksa = mysqli_real_escape_string($host, $_POST['tanggal_periksa']);

// Melakukan query untuk mengupdate data di database
$query = "UPDATE form_pendataran SET nama_lengkap='$nama_lengkap', nomor_identitas='$nomor_identitas', tempat_lahir='$tempat_lahir', tanggal_lahir='$tanggal_lahir', nomor_handphone='$nomor_handphone', no_bpjs='$no_bpjs', jenis_kelamin='$jenis_kelamin', agama='$agama', nama_dokter='$nama_dokter', waktu_periksa='$waktu_periksa', pekerjaan='$pekerjaan', tanggal_periksa='$tanggal_periksa' WHERE no_rm='$no_rm'";

// Memeriksa apakah query berhasil dijalankan
if(mysqli_query($host, $query)) {
    // Jika berhasil, redirect ke halaman index dengan pesan sukses
    header("location:login_succes.php?pesan=update");
} else {
    // Jika gagal, redirect ke halaman index dengan pesan error
    header("location:login_succes.php?pesan=error");
}

// Tutup koneksi ke database
mysqli_close($host);
?>
