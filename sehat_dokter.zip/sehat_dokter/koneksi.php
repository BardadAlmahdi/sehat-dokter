<?php 
$host = mysqli_connect("localhost", "root", "", "form_pendataran");
if (!$host) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

 
?>