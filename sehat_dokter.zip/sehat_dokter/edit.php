<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>sehat_dokter</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Custom Google font-->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet" />
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body class="d-flex flex-column h-100 bg-light">
<main class="flex-shrink-0">
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3">
        <div class="container px-5">
            <a class="navbar-brand" href="index.php"><span class="fw-bolder text-primary">Sehat Dokter</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 small fw-bolder">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="patient registration.php">Patient Registration</a></li>
                    <li class="nav-item"><a class="nav-link" href="teamdoctor.php">Team of Doctor</a></li>
                    <li class="nav-item"><a class="nav-link" href="login.php">Login Admin</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Page Content-->
    <div style="background-color: rgb(255, 255, 255)" class="container p-3 my-2 border">
        <h1 class="text-center">FORM EDIT DATA PASIEN</h1>
        <?php 
        include "koneksi.php";
        $no_rm = $_GET['id'];
        $query = mysqli_query($host, "SELECT * FROM form_pendataran WHERE no_rm ='$no_rm'") or die(mysqli_error($host));
        $data = mysqli_fetch_assoc($query);
        ?>
        <form id="form" action="update.php" method="post">
            <input type="hidden" name="no_rm" value="<?php echo $no_rm; ?>">
            <div class="alert alert-secondary">
                <strong color bg="blue">DATA DIRI PASIEN</strong>
            </div>
            <div class="row">
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Nama Lengkap :</label>
                        <input type="text" name="nama_lengkap" class="form-control" placeholder="Masukkan Nama Lengkap Anda" value="<?php echo $data['nama_lengkap']; ?>">
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Nomor Identitas (NIK) :</label>
                        <input type="text" name="nomor_identitas" class="form-control" placeholder="Masukkan Nomor NIK" value="<?php echo $data['nomor_identitas']; ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Tempat Lahir :</label>
                        <input type="text" name="tempat_lahir" class="form-control" placeholder="Masukkan Tempat Lahir Anda" value="<?php echo $data['tempat_lahir']; ?>">
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Tanggal Lahir :</label>
                        <input type="date" name="tanggal_lahir" class="form-control" placeholder="Masukkan Tanggal Lahir Anda" value="<?php echo $data['tanggal_lahir']; ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Nomor Handphone :</label>
                        <input type="text" name="nomor_handphone" class="form-control" placeholder="Masukkan Nomor Handphone Anda" value="<?php echo $data['nomor_handphone']; ?>">
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Nomor BPJS :</label>
                        <input type="text" name="no_bpjs" class="form-control" placeholder="Masukkan Nomor BPJS Anda" value="<?php echo $data['no_bpjs']; ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Jenis Kelamin :</label>
                        <select class="form-control" name="jenis_kelamin">
                            <option value="">Pilih</option>
                            <option value="Laki-laki" <?php if($data['jenis_kelamin'] == 'Laki-laki') echo 'selected'; ?>>Laki-laki</option>
                            <option value="Perempuan" <?php if($data['jenis_kelamin'] == 'Perempuan') echo 'selected'; ?>>Perempuan</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Agama :</label>
                        <select class="form-control" name="agama">
                            <option value="">Pilih</option>
                            <option value="Islam" <?php if($data['agama'] == 'Islam') echo 'selected'; ?>>Islam</option>
                            <option value="Konghuchu" <?php if($data['agama'] == 'Konghuchu') echo 'selected'; ?>>Konghuchu</option>
                            <option value="Hindu" <?php if($data['agama'] == 'Hindu') echo 'selected'; ?>>Hindu</option>
                            <option value="Budha" <?php if($data['agama'] == 'Budha') echo 'selected'; ?>>Budha</option>
                            <option value="Kristen" <?php if($data['agama'] == 'Kristen') echo 'selected'; ?>>Kristen</option>
                            <option value="Krislam" <?php if($data['agama'] == 'Krislam') echo 'selected'; ?>>Krislam</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Nama Dokter dan Bidang Keahliannya :</label>
                        <select class="form-control" name="nama_dokter">
                            <option value="">Pilih</option>
                            <option value="Dr. John Smith, Spesialis Bedah Jantung." <?php if($data['nama_dokter'] == 'Dr. John Smith, Spesialis Bedah Jantung.') echo 'selected'; ?>>Dr. John Smith, Spesialis Bedah Jantung.</option>
                            <option value="Dr. Sarah Johnson, Dokter Umum." <?php if($data['nama_dokter'] == 'Dr. Sarah Johnson, Dokter Umum.') echo 'selected'; ?>>Dr. Sarah Johnson, Dokter Umum.</option>
                            <option value="Prof. Dr. Michael Brown, Ahli Gastroenterologi."<?php if($data['nama_dokter'] == 'Prof. Dr. Michael Brown, Ahli Gastroenterologi.') echo 'selected'; ?>>Prof. Dr. Michael Brown, Ahli Gastroenterologi.</option>
                            <option value="Dr. Linda Williams, Spesialis Mata."<?php if($data['nama_dokter'] == 'Dr. Linda Williams, Spesialis Mata.') echo 'selected'; ?>>Dr. Linda Williams, Spesialis Mata.</option>
                            <option value="Dr. David Lee, Ahli THT (Telinga, Hidung, Tenggorokan)."<?php if($data['nama_dokter'] == 'Dr. David Lee, Ahli THT (Telinga, Hidung, Tenggorokan).') echo 'selected'; ?>>Dr. David Lee, Ahli THT (Telinga, Hidung, Tenggorokan).</option>
                            <option value="Dr. Jennifer Davis, Spesialis Obstetri dan Ginekologi."<?php if($data['nama_dokter'] == 'Dr. Jennifer Davis, Spesialis Obstetri dan Ginekologi.') echo 'selected'; ?>>Dr. Jennifer Davis, Spesialis Obstetri dan Ginekologi.</option>
                            <option value="Dr. Robert Clark, Dokter Anak."<?php if($data['nama_dokter'] == 'Dr. Robert Clark, Dokter Anak.') echo 'selected'; ?>>Dr. Robert Clark, Dokter Anak.</option>
                            <option value="Dr. James Anderson, Spesialis Bedah Ortopedi."<?php if($data['nama_dokter'] == 'Dr. James Anderson, Spesialis Bedah Ortopedi.') echo 'selected'; ?>>Dr. James Anderson, Spesialis Bedah Ortopedi.</option>
                            <option value="Prof. Dr. Susan Turner, Ahli Radiologi."<?php if($data['nama_dokter'] == 'Prof. Dr. Susan Turner, Ahli Radiologi.') echo 'selected'; ?>>Prof. Dr. Susan Turner, Ahli Radiologi.</option>
                            <option value="Dr. Karen Garcia, Ahli Psikiatri."<?php if($data['nama_dokter'] == 'Dr. Karen Garcia, Ahli Psikiatri.') echo 'selected'; ?>>Dr. Karen Garcia, Ahli Psikiatri.</option>
                            <option value="Dr. Denny Ivan RIfai, Spesialis Penyakit Kulit."<?php if($data['nama_dokter'] == 'Dr. Denny Ivan RIfai, Spesialis Penyakit Kulit.') echo 'selected'; ?>>Dr. Denny Ivan RIfai, Spesialis Penyakit Kulit.</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Waktu Periksa :</label>
                        <input type="time" name="waktu_periksa" class="form-control" placeholder="Masukkan Waktu Periksa Anda" value="<?php echo $data['waktu_periksa']; ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Pekerjaan :</label>
                        <input type="text" name="pekerjaan" class="form-control" placeholder="Masukkan Pekerjaan Anda" value="<?php echo $data['pekerjaan']; ?>">
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="form-group">
                        <label for="">Tanggal Periksa :</label>
                        <input type="date" name="tanggal_periksa" class="form-control" placeholder="Masukkan Tanggal Periksa Anda" value="<?php echo $data['tanggal_periksa']; ?>">
                    </div>
                </div>
            </div>
            <br>
            <center>
                <input type="submit" class="btn btn-success" value="Simpan">
                <input class="btn btn-primary" type="reset" value="Reset">
            </center>
        </form>
    </div>
</main>
<!-- Footer-->
<footer class="bg-white py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0">Kemudahan Akses || Efesiensi Waktu || Menghindari Antrian</div></div>
            <div class="col-auto">
                <a class="small" href="#!">Privacy</a>
                <span class="mx-1">&middot;</span>
                <a class="small" href="#!">Terms</a>
                <span class="mx-1">&middot;</span>
                <a class="small" href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
</body>
</html>
