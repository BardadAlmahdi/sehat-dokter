<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Login succes</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Custom Google font-->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet" />
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body class="d-flex flex-column h-100">
<main class="flex-shrink-0">
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3">
        <div class="container px-5">
            <a class="navbar-brand" href="index.php"><span class="fw-bolder text-primary">Sehat Dokter</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 small fw-bolder">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="patient registration.php">Patient Registration</a></li>
                    <li class="nav-item"><a class="nav-link" href="teamdoctor.php">Team of Doctor</a></li>
                    <li class="nav-item"><a class="nav-link" href="login.php">Login Admin</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <?php 
        include "koneksi.php";
        if(isset($_GET['pesan'])){
            $pesan = $_GET['pesan'];
            if($pesan == "input"){
                echo '<div class="alert alert-success" role="alert">Data pasien berhasil ditambahkan.</div>';
            }else if($pesan == "update"){
                echo '<div class="alert alert-success" role="alert">Data berhasil di update.</div>';
            }else if($pesan == "hapus"){
                echo '<div class="alert alert-success" role="alert">Data berhasil dihapus.</div>';
            }
        }
        ?>

        <a class="btn btn-primary mb-3" href="patient registration.php">Tambah Data Baru</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Nomor Rumah Sakit</th>
                    <th scope="col">Nama Lengkap</th>
                    <th scope="col">Nomor Identitas (NIK)</th>
                    <th scope="col">Tempat Lahir</th>
                    <th scope="col">Tanggal Lahir</th>
                    <th scope="col">Nomor Handphone</th>
                    <th scope="col">Nomor BPJS</th>
                    <th scope="col">Jenis Kelamin</th>
                    <th scope="col">Agama</th>
                    <th scope="col">Nama Dokter dan Bidang Keahlian</th>
                    <th scope="col">Waktu Periksa</th>
                    <th scope="col">Pekerjaan</th>
                    <th scope="col">Tanggal Periksa</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $query_mysql = mysqli_query($host, "SELECT * FROM form_pendataran")or die(mysqli_error($host));
                $no_rm = 1;
                while($data = mysqli_fetch_array($query_mysql)){
                ?>
                <tr>
                    <th scope="row"><?php echo $no_rm++; ?></th>
                    <td><?php echo $data['nama_lengkap']; ?></td>
                    <td><?php echo $data['nomor_identitas']; ?></td>
                    <td><?php echo $data['tempat_lahir']; ?></td>
                    <td><?php echo $data['tanggal_lahir']; ?></td>
                    <td><?php echo $data['nomor_handphone']; ?></td>
                    <td><?php echo $data['no_bpjs']; ?></td>
                    <td><?php echo $data['jenis_kelamin']; ?></td>
                    <td><?php echo $data['agama']; ?></td>
                    <td><?php echo $data['nama_dokter']; ?></td>
                    <td><?php echo $data['waktu_periksa']; ?></td>
                    <td><?php echo $data['pekerjaan']; ?></td>
                    <td><?php echo $data['tanggal_periksa']; ?></td>
                    <td>
                        <a class="btn btn-warning btn-sm" href="edit.php?id=<?php echo $data['no_rm']; ?>">Edit</a>
                        <a class="btn btn-danger btn-sm" href="hapus.php?id=<?php echo $data['no_rm']; ?>">Hapus</a>                    
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</main>
<!-- Footer-->
<footer class="bg-white py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0">Kemudahan Akses || Efesiensi Waktu || Menghindari Antrian</div></div>
            <div class="col-auto">
                <a class="small" href="#!">Privacy</a>
                <span class="mx-1">&middot;</span>
                <a class="small" href="#!">Terms</a>
                <span class="mx-1">&middot;</span>
                <a class="small" href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
</body>
</html>
