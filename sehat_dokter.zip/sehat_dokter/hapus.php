<?php 
include 'koneksi.php';
$no_rm = $_GET['id'];

// Melakukan query DELETE dengan mysqli
$query = "DELETE FROM form_pendataran WHERE no_rm='$no_rm'";
if (mysqli_query($host, $query)) {
    // Jika berhasil menghapus, redirect ke halaman index dengan pesan sukses
    header("location:login_succes.php?pesan=hapus");
} else {
    // Jika gagal, tampilkan pesan kesalahan
    die("Gagal menghapus data: " . mysqli_error($host));
}
?>
