<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>sehat_dokter</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Custom Google font-->
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body class="d-flex flex-column h-100 bg-light">
        <main class="flex-shrink-0">
            <!-- Navigation-->
            <nav class="navbar navbar-expand-lg navbar-light bg-white py-3">
                <div class="container px-5">
                    <a class="navbar-brand" href="index.php"><span class="fw-bolder text-primary">Sehat Dokter</span></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 small fw-bolder">
                            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="patient registration.php">Patient Registration</a></li>
                            <li class="nav-item"><a class="nav-link" href="teamdoctor.php">Team of Doctor</a></li>
                            <li class="nav-item"><a class="nav-link" href="login.php">Login Admin</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- Page Content-->
            <div style="background-color: rgb(255, 255, 255)"; class="container p-3 my-2 border">
                <h1 class="text-center">FORM PENDAFTARAN PASIEN</h1>
                <form id="form" action="register-aksi.php" method="post">
                    <div class="alert alert-secondary">
                        <strong color bg="blue">DATA DIRI PASIEN</strong>
                    </div>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="form-grup">
                            <label>Nama Lengkap : </label>
                            <input type="text" name="nama_lengkap" class="form-control" placeholder="Masukan Nama Lengakap Anda">
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-grup">
                            <label>Nomor Identitas (NIK) : </label>
                            <input type="text" name="nomor_identitas" class="form-control" placeholder="Masukan Nomor NIK">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="form-grup">
                                <label for="">Tempat Lahir :</label>
                                <input type="text" name="tempat_lahir" class="form-control" placeholder="masukan tempat lahir Anda">
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-grup">
                                <label for="">Tanggal Lahir :</label>
                                <input type="date" name="tanggal_lahir" class="form-control" placeholder="masukan tanggal lahir Anda">
                            </div>
                        </div>
            
                    </div>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="form-grup">
                                <label for="">Nomor Handphone :</label>
                                <input type="text" name="nomor_handphone" class="form-control" placeholder="masukan Nomor Handphone Anda">
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-grup">
                                <label for="">Nomor BPJS :</label>
                                <input type="text" name="no_bpjs" class="form-control" placeholder="masukan nomor BPJS anda">
                            </div>
                        </div>
            
                    </div>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="form-grup">
                            <label for="">jenis Kelamin</label>
                            <select class="form-control" name="jenis_kelamin">
                                <option value="">Pilih</option>
                                <option value="Laki-laki">Laki-laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>                 
                                
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-grup">
                            <label for="">Agama</label>
                            <select class="form-control" name="agama">
                                <option value="">Pilih</option>
                                <option value="Islam">Islam</option>
                                <option value="Konghuchu">Konghuchu</option>
                                <option value="Hindu">Hindu</option>
                                <option value="Budha">Budha</option>
                                <option value="Kristen">Kristen</option>
                                <option value="Krislam">Krislam</option>
                            </select>                 
                            </div>
                        </div>
                            
            
                    </div>
                            <div class="row">
                        <div class="col-sm-5">
                            <div class="form-grup">
                            <label for="">Nama Dokter dan Bidang keahliannya</label>
                            <select class="form-control" name="nama_dokter">
                                <option value="">Pilih</option>
                                <option value="Nama Dokter">Dr. John Smith, Spesialis Bedah Jantung.</option>
                                <option value="Nama Dokter">Dr. Sarah Johnson, Dokter Umum.</option>
                                <option value="Nama Dokter">Prof. Dr. Michael Brown, Ahli Gastroenterologi.</option>
                                <option value="Nama Dokter">Dr. Linda Williams, Spesialis Mata</option>
                                <option value="Nama Dokter">Dr. David Lee, Ahli THT (Telinga, Hidung, Tenggorokan).</option>
                                <option value="Nama Dokter">Dr. Jennifer Davis, Spesialis Obstetri dan Ginekologi.</option>
                                <option value="Nama Dokter">Dr. Robert Clark, Dokter Anak.</option>
                                <option value="Nama Dokter">Dr. James Anderson, Spesialis Bedah Ortopedi..</option>
                                <option value="Nama Dokter">Prof. Dr. Susan Turner, Ahli Radiologi.</option>
                                <option value="Nama Dokter">Dr. Karen Garcia, Ahli Psikiatri.</option>
                                <option value="Nama Dokter">Dr. Denny Ivan RIfai, Spesialis Penyakit Kulit.</option>
                            </select>                 
                                
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-grup">
                            <label for="">Waktu Periksa</label>
                                <input type="time" name="waktu_periksa" class="form-control" placeholder="masukan tanggal lahir Anda">             
                            </div>
                        </div>
                            
            
                    </div>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="form-grup">
                                <label for="">Pekerjaan :</label>
                                <input type="text" name="pekerjaan" class="form-control" placeholder="masukan Pekerjaan Anda">
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-grup">
                                <label for="">Tanggal Periksa :</label>
                                <input type="date" name="tanggal_periksa" class="form-control" placeholder="masukan tempat lahir Anda">
                            </div>
                        </div>
            
                    </div><br>
                    <center>
                    <tr>
				<td></td>
				<td><input type="submit" class="btn btn-success" value="Simpan"></td>					
			    </tr>
                      <!--  <a href="succes.php"><button type="button" class="btn btn-success">Success</button></a> -->
                    <input class="btn btn-primary" type="reset" value="Reset">
                    </center>
                </div>

                

                </form>
                </div>
        
        </main>
        <!-- Footer-->
        <footer class="bg-white py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0">Kemudahan Akses || Efesiensi Waktu || Menghindari Antrian</div></div>
                    <div class="col-auto">
                        <a class="small" href="#!">Privacy</a>
                        <span class="mx-1">&middot;</span>
                        <a class="small" href="#!">Terms</a>
                        <span class="mx-1">&middot;</span>
                        <a class="small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
